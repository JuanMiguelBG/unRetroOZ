#!/bin/bash

pre_update()
{
   print_log $UPDATE_LOG_FILE "INFO" "Executing pre_update()"
   return 0
}

update()
{
   print_log $UPDATE_LOG_FILE "INFO" "Executing update()"
   return 0

}

post_update()
{
   print_log $UPDATE_LOG_FILE "INFO" "Executing post_update()"
   return 0
}

# ******************************************************************************************


UPDATE_LOG_FILE="/roms/logs/retrooz_update_0_61.log"

# Clean the update log file
sudo rm -f $UPDATE_LOG_FILE
touch $UPDATE_LOG_FILE

# Configure ES commons variables
. es-log_scripts

do_active_console_log $UPDATE_LOG_FILE

UPDATE_MESSAGE_FILE="$ES_HOME_PATH/update_result_message.txt"


exit_execution()
{
    local return=$1
    print_log $UPDATE_LOG_FILE "INFO" "##### Exit executing update, exit code: '$return' #####"
    do_close_console_log $UPDATE_LOG_FILE
    exit $return
}

pre_update
if [ $? -eq 1 ]; then
   # fail
   print_log $UPDATE_LOG_FILE "INFO" "Execute post_update() failed"
   exit_execution 1
fi

update
if [ $? -eq 1 ]; then
   # fail
   print_log $UPDATE_LOG_FILE "INFO" "Execute update() failed"
   exit_execution 1
fi


post_update
if [ $? -eq 1 ]; then
   # fail
   print_log $UPDATE_LOG_FILE "INFO" "Execute post_update() failed"
   exit_execution 1
fi

exit_execution 0
